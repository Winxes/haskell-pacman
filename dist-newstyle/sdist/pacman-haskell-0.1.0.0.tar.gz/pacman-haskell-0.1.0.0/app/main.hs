import Control.Monad (mapM_)
import System.Console.ANSI (clearScreen, setSGR, Color(..), ColorIntensity(..), ConsoleLayer(..), SGR(..))
import System.Random (randomRIO)
import Data.Maybe (fromMaybe)
import Data.List (foldl', (\\))

-- Definição dos tipos
data Map
  = Road (Int, Int)
  | Wall (Int, Int)
  deriving (Show)

data Entity = Entity
  { entityName :: String
  , maxScore   :: Int
  , position   :: (Int, Int)
  } deriving (Show)

-- Função para criar uma matriz 36x28 de Map sem ScoredRoad
criarMatriz :: [[Map]]
criarMatriz = [[elemento (r, c) | c <- [0..27]] | r <- [0..35]]
  where
    elemento (r, c)
      | r == 0 || r == 35 || c == 0 || c == 27 = Wall (r, c)  -- Bordas
      | r `mod` 2 == 0 && c `mod` 2 == 0 = Wall (r, c)  -- Padrão de paredes
      | otherwise = Road (r, c)  -- Caminhos internos

-- Função para converter um Map em uma letra/símbolo
mapToSymbol :: Map -> String
mapToSymbol (Road _) = "."
mapToSymbol (Wall _) = "🞓"

-- Função para imprimir a matriz, considerando as posições das entidades
printMatrizComEntidades :: [[Map]] -> [Entity] -> IO ()
printMatrizComEntidades matriz entidades = mapM_ (putStrLn . unwords . map (mostrarComEntidades entidades)) coordenadas
  where
    coordenadas = [[(r, c) | c <- [0..27]] | r <- [0..35]]
    mostrarComEntidades ents (r, c) =
      case filter (\(Entity _ _ (er, ec)) -> (er, ec) == (r, c)) ents of
        [] -> mapToSymbol (matriz !! r !! c)
        (Entity nome _ _ : _) -> 
          case nome of
            "Pacman"   -> "\ESC[33mP\ESC[0m"
            "Azul"     -> "A"
            "Vermelho" -> "R"
            "Rosa"     -> "O"
            "Laranja"  -> "L"
            _          -> "G"

-- Função para criar uma entidade com nome, posição e maxScore zerado
criarEntidade :: String -> (Int, Int) -> Entity
criarEntidade nome pos = Entity { entityName = nome, maxScore = 0, position = pos }

-- Função para capturar e verificar o caractere do usuário e atualizar a posição
moverPacman :: [[Map]] -> Entity -> Char -> Entity
moverPacman matriz pacman movimento =
  let (r, c) = position pacman
      novaPos = case movimento of
        'w' -> (r - 1, c)  -- Mover para cima
        's' -> (r + 1, c)  -- Mover para baixo
        'a' -> (r, c - 1)  -- Mover para a esquerda
        'd' -> (r, c + 1)  -- Mover para a direita
        _   -> (r, c)      -- Movimento inválido
  in if isMovimentoValido matriz novaPos
       then pacman { position = novaPos }
       else pacman  -- Se o movimento for inválido, a posição não muda

-- Função para verificar se a nova posição é válida (não é uma parede)
isMovimentoValido :: [[Map]] -> (Int, Int) -> Bool
isMovimentoValido matriz (r, c) =
  case matriz !! r !! c of
    Road _ -> True
    Wall _ -> False

-- Função para encontrar o menor caminho usando BFS
menorCaminho :: [[Map]] -> (Int, Int) -> (Int, Int) -> Maybe [(Int, Int)]
menorCaminho matriz inicio destino = bfs [inicio] []
  where
    bfs [] _ = Nothing
    bfs (current:rest) visited
      | current == destino = Just (reverse (current : path))
      | otherwise = bfs (rest ++ nextSteps) (current : visited)
      where
        (path, nextSteps) = foldl' processStep ([], []) neighbors
        neighbors = [(r+dr, c+dc) | (r, c) <- [current], (dr, dc) <- [(-1,0), (1,0), (0,-1), (0,1)]]
        processStep (p, ns) (nr, nc)
          | isMovimentoValido matriz (nr, nc) && notElem (nr, nc) visited =
              (p, (nr, nc) : ns)
          | otherwise = (p, ns)

-- Função para mover o fantasma em direção ao Pacman
moverFantasma :: [[Map]] -> Entity -> Entity -> IO Entity
moverFantasma matriz fantasma pacman = do
  chance <- randomRIO (1, 100)
  let seguirMenorCaminho = chance <= 30
  let novaPos = if seguirMenorCaminho
                then fromMaybe (position fantasma) (menorCaminho matriz (position fantasma) (position pacman))
                else randomMove matriz (position fantasma)
  return $ fantasma { position = novaPos }

-- Função para gerar um movimento aleatório válido
randomMove :: [[Map]] -> (Int, Int) -> (Int, Int)
randomMove matriz (r, c) = head $ filter (isMovimentoValido matriz) [(r-1, c), (r+1, c), (r, c-1), (r, c+1)]

-- Função principal de jogo
main :: IO ()
main = do
  let matriz = criarMatriz
  let pacman = criarEntidade "Pacman" (19, 13)
  let azul = criarEntidade "Azul" (14, 13)
  let vermelho = criarEntidade "Vermelho" (13, 12)
  let rosa = criarEntidade "Rosa" (13, 13)
  let laranja = criarEntidade "Laranja" (13, 14)

  let entidades = [azul, vermelho, rosa, laranja]

  -- Loop principal do jogo
  gameLoop matriz pacman entidades

-- Loop principal do jogo
gameLoop :: [[Map]] -> Entity -> [Entity] -> IO ()
gameLoop matriz pacman entidades = do
  clearScreen -- Limpa o terminal
  let entidadesComPacman = pacman : entidades
  printMatrizComEntidades matriz entidadesComPacman
  putStrLn "Digite um movimento (w, s, a, d):"
  movimento <- getChar
  let novoPacman = moverPacman matriz pacman movimento
  fantasmasMovidos <- mapM (moverFantasma matriz novoPacman) (filter (\e -> entityName e /= "Pacman") entidades)
  let todasEntidades = novoPacman : fantasmasMovidos
  gameLoop matriz novoPacman todasEntidades
